extends Control

const FOREST_PATH := "res://scenes/forest.tscn"
const INSTRUCTIONS := [
	["WASD / стрелки", "Движење"],
	["Shift", "Трчање"],
	["Space / J", "Електричен удар"],
	["Tab (држи)", "Мапа"],
	["Esc", "Пауза / продолжи"],
	["R", "Рестарт"],
	["M", "Музика вкл. / искл."],
]

var is_result := false
var won := false
var final_score := 0

@onready var title: Label = %Title
@onready var subtitle: Label = %Subtitle
@onready var actions: VBoxContainer = %Actions
@onready var instructions: VBoxContainer = %Instructions

func configure_result(victory: bool, score: int) -> void:
	is_result = true
	won = victory
	final_score = score

func _ready() -> void:
	resized.connect(queue_redraw)
	if is_result:
		title.text = "Патеката е завршена" if won else "Нема повеќе животи"
		title.add_theme_font_size_override("font_size", 35)
		subtitle.text = "Освоени поени   %d" % final_score
		%Start.text = "Play Again"
		%Options.hide()
	%Start.grab_focus()

func _start_game() -> void:
	get_tree().change_scene_to_file(FOREST_PATH)

func _open_options() -> void:
	if %Controls.get_child_count() == 0:
		for binding in INSTRUCTIONS:
			var key := Label.new()
			key.text = binding[0]
			key.add_theme_color_override("font_color", Color("f6d48e"))
			%Controls.add_child(key)
			var action := Label.new()
			action.text = binding[1]
			%Controls.add_child(action)
	title.text = "Контроли"
	subtitle.text = "Собери ги сите три кристали со допир."
	actions.hide()
	instructions.show()
	%Back.grab_focus()

func _close_options() -> void:
	title.text = "Shadowbound"
	subtitle.text = "Шумската патека"
	instructions.hide()
	actions.show()
	%Options.grab_focus()

func _quit_game() -> void:
	get_tree().quit()

func _unhandled_input(event: InputEvent) -> void:
	if instructions.visible and event is InputEventKey and event.pressed and event.physical_keycode == KEY_ESCAPE:
		_close_options()
		get_viewport().set_input_as_handled()

func _draw() -> void:
	if is_result:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.025, 0.07, 0.06, 0.76))
		return

	draw_rect(Rect2(Vector2.ZERO, size), Color("132e29"))
	var light := size * Vector2(0.53, 0.42)
	for index in 13:
		draw_circle(light, size.x * (0.38 - index * 0.021), Color(0.38, 0.58, 0.42, 0.032), true, -1.0, true)

	for layer in 3:
		var ground_y := size.y * (0.77 + layer * 0.095)
		var shade: Color = [Color("25463a"), Color("19372e"), Color("112922")][layer]
		var spacing := 76.0 - layer * 8.0
		draw_rect(Rect2(0, ground_y, size.x, size.y - ground_y), shade)
		for index in ceili(size.x / spacing) + 2:
			var x := index * spacing + cos(index * 4.3 + layer) * 31.0
			if layer > 0 and x > size.x * 0.3 and x < size.x * 0.71:
				continue
			var height := (110.0 + (sin(index * 2.7 + layer * 1.3) + 1.0) * 84.0) * (1.0 + layer * 0.38)
			for crown in 3:
				var y := ground_y - height * (0.12 + crown * 0.23)
				var width := height * (0.24 - crown * 0.035)
				var silhouette := PackedVector2Array([Vector2(x - width, y), Vector2(x, y - height * 0.57), Vector2(x + width, y)])
				draw_colored_polygon(silhouette, shade)
			draw_rect(Rect2(x - 6, ground_y - height * 0.19, 12, height * 0.21), shade)
