extends Node2D

const STARTING_LIVES := 3
const RESPAWN_DELAY := 1.0
const END_SCREEN := preload("res://scenes/menu.tscn")
const BINDINGS := {
	"move_left": [KEY_A, KEY_LEFT], "move_right": [KEY_D, KEY_RIGHT],
	"move_up": [KEY_W, KEY_UP], "move_down": [KEY_S, KEY_DOWN],
	"sprint": [KEY_SHIFT], "reset": [KEY_R], "pause_game": [KEY_ESCAPE],
	"mute": [KEY_M], "map": [KEY_TAB], "attack": [KEY_SPACE, KEY_J],
}

@export var music_enabled := true
var score := 0
var lives := STARTING_LIVES
var remaining_collectables := 0
var paused := false
var muted := false
var ending := false
var restarting := false
var respawn_time := 0.0
var spawn_position: Vector2

@onready var player: CharacterBody2D = $World/Player
@onready var music: AudioStreamPlayer = $Music
@onready var hud: Control = $HUD/Interface
@onready var collectables: Node2D = $World/Collectables

func _ready() -> void:
	for action in BINDINGS:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
		for key in BINDINGS[action]:
			var event := InputEventKey.new()
			event.physical_keycode = key
			if not InputMap.action_has_event(action, event):
				InputMap.action_add_event(action, event)

	spawn_position = player.global_position
	hud.update_totals(score, lives)
	player.died.connect(_on_player_died)
	remaining_collectables = collectables.get_child_count()
	for item in collectables.get_children():
		item.picked_up.connect(_on_collectable_picked_up.bind(item))

	var track := music.stream as AudioStreamWAV
	track.loop_mode = AudioStreamWAV.LOOP_FORWARD
	track.loop_end = int(track.get_length() * track.mix_rate)
	if music_enabled and DisplayServer.get_name() != "headless":
		music.play()

func _on_collectable_picked_up(points: int, item: Area2D) -> void:
	score += points
	remaining_collectables -= 1
	hud.update_totals(score, lives)
	if remaining_collectables == 0:
		ending = true
		player.controls_enabled = false
		player.velocity = Vector2.ZERO
		player.attack_time = 0.0
		player.queue_redraw()
		item.pickup_finished.connect(_show_end_screen.bind(true), CONNECT_ONE_SHOT)

func _on_player_died() -> void:
	lives -= 1
	hud.update_totals(score, lives)
	respawn_time = RESPAWN_DELAY

func _physics_process(delta: float) -> void:
	if respawn_time <= 0.0:
		return
	respawn_time = maxf(0.0, respawn_time - delta)
	if respawn_time > 0.0:
		return
	if lives > 0:
		player.respawn_at(spawn_position)
	else:
		ending = true
		_show_end_screen(false)

func _show_end_screen(won: bool) -> void:
	hud.hide()
	var screen := END_SCREEN.instantiate()
	screen.configure_result(won, score)
	$HUD.add_child(screen)

func restart_level() -> void:
	if restarting:
		return
	restarting = true
	get_tree().call_deferred("reload_current_scene")

func _process(_delta: float) -> void:
	if ending or player.dead or restarting:
		hud.set_map_visible(false)
		return
	if Input.is_action_just_pressed("reset"):
		restart_level()
		return
	if Input.is_action_just_pressed("pause_game"):
		paused = not paused
		player.controls_enabled = not paused
		player.velocity = Vector2.ZERO
		hud.queue_redraw()
	if Input.is_action_just_pressed("mute"):
		muted = not muted
		music.volume_db = -80 if muted else -22
	hud.set_map_visible(not paused and Input.is_action_pressed("map"))
