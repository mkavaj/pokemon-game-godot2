extends Control

const MAP_REGIONS := [
	Rect2(128, 768, 640, 640),
	Rect2(768, 896, 192, 128),
	Rect2(960, 512, 576, 704),
	Rect2(1536, 576, 128, 128),
	Rect2(1664, 192, 512, 640),
]
const MAP_SCALE := 0.24
const MAP_SIZE := Vector2(2304, 1536) * MAP_SCALE
const TEXT_COLOR := Color("f1ecd7")

var map_visible := false
var overlay_style := StyleBoxFlat.new()
@onready var level: Node2D = get_parent().get_parent()

func _ready() -> void:
	resized.connect(queue_redraw)
	overlay_style.bg_color = Color("142723")
	overlay_style.border_color = Color("61755a")
	overlay_style.set_border_width_all(1)
	overlay_style.set_corner_radius_all(14)

func update_totals(points: int, lives: int) -> void:
	%Score.text = str(points)
	%Lives.text = str(lives)

func set_map_visible(visible_now: bool) -> void:
	if map_visible or visible_now:
		map_visible = visible_now
		queue_redraw()

func _draw() -> void:
	if level.paused:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.02, 0.06, 0.05, 0.72))
		var bounds := Rect2((size - Vector2(330, 110)) / 2, Vector2(330, 110))
		draw_style_box(overlay_style, bounds)
		_draw_centered("Пауза", bounds.position.y + 47, 27)
		_draw_centered("Esc за продолжување", bounds.position.y + 79, 16)
	elif map_visible:
		var origin := (size - MAP_SIZE) / 2
		draw_style_box(overlay_style, Rect2(origin, MAP_SIZE).grow(12))
		for region in MAP_REGIONS:
			draw_rect(Rect2(origin + region.position * MAP_SCALE, region.size * MAP_SCALE), Color("4c7057"))
		for item in level.collectables.get_children():
			if not item.claimed:
				draw_circle(origin + item.position * MAP_SCALE, 5, Color("f2c777"), true, -1.0, true)
		var player_mark: Vector2 = origin + level.player.position * MAP_SCALE
		draw_circle(player_mark, 5, Color("fff3bb"), true, -1.0, true)
		draw_arc(player_mark, 9, 0, TAU, 20, Color("fff3bb"), 1.5, true)

func _draw_centered(text: String, y: float, font_size: int) -> void:
	var font := ThemeDB.fallback_font
	var width := font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	draw_string(font, Vector2((size.x - width) / 2, y), text, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, TEXT_COLOR)
