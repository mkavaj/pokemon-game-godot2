extends Area2D

signal picked_up(points: int)
signal pickup_finished

const PICKUP_DURATION := 0.48
const GOLD := Color("ffda82")
const SHINE := Color("fff3bb")

@export_range(1, 1000) var points := 100
var claimed := false
var elapsed := 0.0
var pickup_time := 0.0

func _ready() -> void:
	elapsed = position.x * 0.013 + position.y * 0.01

func _physics_process(_delta: float) -> void:
	if claimed:
		return
	# Only the player's feet are on the collision layer this area monitors.
	for body in get_overlapping_bodies():
		if body.controls_enabled and not body.dead:
			claimed = true
			set_deferred("monitoring", false)
			set_physics_process(false)
			picked_up.emit(points)
			break

func _process(delta: float) -> void:
	elapsed += delta
	if claimed:
		pickup_time += delta
		if pickup_time >= PICKUP_DURATION:
			pickup_finished.emit()
			queue_free()
			return
	queue_redraw()

func _draw() -> void:
	if claimed:
		_draw_pickup()
		return

	var bob := sin(elapsed * 3.2) * 5.0
	var glint := 0.65 + 0.35 * sin(elapsed * 5.0)
	var center := Vector2(0, -24 + bob)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.35))
	draw_circle(Vector2.ZERO, 16, Color("10251e"), true, -1.0, true)
	draw_arc(Vector2.ZERO, 20, 0, TAU, 24, Color(GOLD, 0.6), 2.0, true)
	draw_set_transform(center)
	draw_circle(Vector2.ZERO, 21, Color(GOLD, 0.15 * glint), true, -1.0, true)
	var top := Vector2(0, -17)
	var right := Vector2(12, -3)
	var bottom := Vector2(0, 16)
	var left := Vector2(-12, -3)
	draw_colored_polygon(PackedVector2Array([top, right, bottom, left]), GOLD)
	draw_colored_polygon(PackedVector2Array([top, right, bottom, Vector2(2, -2)]), Color("d38938"))
	draw_colored_polygon(PackedVector2Array([top, Vector2(2, -2), left]), SHINE)
	draw_polyline(PackedVector2Array([top, right, bottom, left, top]), Color("ffebaa"), 2.0, true)
	draw_circle(Vector2(13, -14), 1.5 + 1.5 * glint, SHINE, true, -1.0, true)

func _draw_pickup() -> void:
	var progress := pickup_time / PICKUP_DURATION
	var fade := 1.0 - progress
	var center := Vector2(0, -24)
	draw_arc(center, 9 + progress * 34, 0, TAU, 32, Color(GOLD, fade), 2.0, true)
	for index in 8:
		var direction := Vector2.from_angle(index * TAU / 8 + PI / 8)
		var spark := center + direction * (9 + progress * 46)
		draw_line(spark, spark + direction * 7 * fade, Color(SHINE, fade), 3.0, true)
	var font := ThemeDB.fallback_font
	var text := "+%d" % points
	var width := font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, 19).x
	draw_string(font, Vector2(-width / 2, -24 - progress * 24), text, HORIZONTAL_ALIGNMENT_LEFT, -1, 19, Color(SHINE, fade))
